/**
 * Firebase Admin SDK - used server-side only (API routes)
 * Provides privileged access to Realtime Database, Storage, and Auth verification
 */
import admin from "firebase-admin";

let adminApp: admin.app.App | null = null;

function getAdminApp() {
  if (adminApp) return adminApp;

  if (admin.apps.length > 0) {
    adminApp = admin.apps[0]!;
    return adminApp;
  }

  // Use service account from env if available (production),
  // otherwise fall back to applicationDefault (Vercel/Google Cloud)
  const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT
    ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)
    : undefined;

  adminApp = admin.initializeApp({
    credential: serviceAccount
      ? admin.credential.cert(serviceAccount)
      : admin.credential.applicationDefault(),
    databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  });

  return adminApp;
}

export const adminDb = () => admin.database(getAdminApp());
export const adminAuth = () => admin.auth(getAdminApp());
export const adminStorage = () => admin.storage(getAdminApp());
export { admin };
export default getAdminApp;
