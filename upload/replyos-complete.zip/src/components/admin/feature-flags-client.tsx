"use client";

import * as React from "react";
import { PageHeader } from "./page-header";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/components/language-provider";
import { Flag, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

interface FlagItem {
  key: string;
  label: string;
  labelAr: string;
  enabled: boolean;
}

interface Props {
  flags: FlagItem[];
}

export function FeatureFlagsClient({ flags: initial }: Props) {
  const { lang } = useLanguage();
  const [flags, setFlags] = React.useState(initial);

  const toggleFlag = (key: string) => {
    setFlags((prev) =>
      prev.map((f) => (f.key === key ? { ...f, enabled: !f.enabled } : f))
    );
    const flag = flags.find((f) => f.key === key);
    toast.success(
      `${lang === "ar" ? flag?.labelAr : flag?.label} — ${flag?.enabled ? (lang === "ar" ? "معطل" : "Disabled") : (lang === "ar" ? "مفعّل" : "Enabled")}`
    );
  };

  return (
    <div>
      <PageHeader
        title={lang === "ar" ? "ميزات تجريبية" : "Feature Flags"}
        description={lang === "ar" ? "تحكم في الميزات دون إعادة النشر" : "Toggle features without redeployment"}
        action={
          <Button onClick={() => toast.info(lang === "ar" ? "إضافة ميزة" : "Add feature")}>
            <Plus className="w-4 h-4 me-2" />
            {lang === "ar" ? "ميزة جديدة" : "Add Flag"}
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {flags.map((flag, i) => (
          <Card key={flag.key} className="p-5 premium-shadow hover:premium-shadow-lg transition-all animate-fade-in">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <Flag className="w-5 h-5" />
              </div>
              <Switch checked={flag.enabled} onCheckedChange={() => toggleFlag(flag.key)} />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{lang === "ar" ? flag.labelAr : flag.label}</p>
              <code className="text-xs text-muted-foreground font-mono mt-1 block">{flag.key}</code>
            </div>
            <div className="mt-3 pt-3 border-t border-border">
              <Badge variant={flag.enabled ? "default" : "secondary"}>
                {flag.enabled ? (lang === "ar" ? "مفعّل" : "Enabled") : (lang === "ar" ? "معطل" : "Disabled")}
              </Badge>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
