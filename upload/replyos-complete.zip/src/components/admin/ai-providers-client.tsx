"use client";

import * as React from "react";
import { PageHeader } from "./page-header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useLanguage } from "@/components/language-provider";
import { Plus, Bot, Trash2, Edit, Zap, Activity, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { AI_PROVIDERS } from "@/lib/constants";
import type { AIProviderData } from "@/lib/admin-data";

interface Props {
  providers: AIProviderData[];
}

export function AIProvidersClient({ providers: initial }: Props) {
  const { lang } = useLanguage();
  const [providers, setProviders] = React.useState(initial);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [testing, setTesting] = React.useState<string | null>(null);

  const [form, setForm] = React.useState({
    name: "",
    provider: "zai",
    model: "glm-4.6",
    apiKey: "",
    endpoint: "https://api.z.ai/api/paas/v4",
  });

  const toggleActive = (id: string) => {
    setProviders((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isActive: !p.isActive } : p))
    );
    const provider = providers.find((p) => p.id === id);
    toast.success(
      provider?.isActive
        ? lang === "ar" ? "تم تعطيل المزود" : "Provider disabled"
        : lang === "ar" ? "تم تفعيل المزود" : "Provider enabled"
    );
  };

  const handleTest = async (id: string) => {
    setTesting(id);
    try {
      const res = await fetch("/api/ai/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ providerId: id }),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success(lang === "ar" ? "الاتصال ناجح!" : "Connection successful!");
      } else {
        toast.error(data.error || (lang === "ar" ? "فشل الاتصال" : "Connection failed"));
      }
    } catch {
      toast.error(lang === "ar" ? "خطأ في الاتصال" : "Connection error");
    } finally {
      setTesting(null);
    }
  };

  const handleSave = () => {
    if (!form.name || !form.model) {
      toast.error(lang === "ar" ? "يرجى ملء الحقول المطلوبة" : "Please fill required fields");
      return;
    }
    const newProvider: AIProviderData = {
      id: `prov_${Date.now()}`,
      name: form.name,
      provider: form.provider,
      model: form.model,
      isActive: false,
      isDefault: false,
      apiKeyMasked: form.apiKey ? `${form.apiKey.slice(0, 3)}••••••••${form.apiKey.slice(-4)}` : "••••••••",
      endpoint: form.endpoint,
      usageThisMonth: 0,
    };
    setProviders((prev) => [...prev, newProvider]);
    setDialogOpen(false);
    setForm({ name: "", provider: "zai", model: "glm-4.6", apiKey: "", endpoint: "https://api.z.ai/api/paas/v4" });
    toast.success(lang === "ar" ? "تم إضافة المزود" : "Provider added");
  };

  const handleDelete = (id: string) => {
    setProviders((prev) => prev.filter((p) => p.id !== id));
    toast.success(lang === "ar" ? "تم حذف المزود" : "Provider deleted");
  };

  return (
    <div>
      <PageHeader
        title={lang === "ar" ? "مزودو الذكاء الاصطناعي" : "AI Providers"}
        description={lang === "ar" ? "إدارة مزودي الذكاء الاصطناعي والإعدادات" : "Manage AI providers and configurations"}
        action={
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="w-4 h-4 me-2" />
            {lang === "ar" ? "مزود جديد" : "Add Provider"}
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {providers.map((provider) => (
          <Card key={provider.id} className="p-5 premium-shadow animate-fade-in">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                  provider.isActive ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                }`}>
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">{provider.name}</h3>
                    {provider.isDefault && (
                      <Badge variant="secondary" className="text-xs">
                        {lang === "ar" ? "افتراضي" : "Default"}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {provider.provider} · {provider.model}
                  </p>
                </div>
              </div>
              <Switch checked={provider.isActive} onCheckedChange={() => toggleActive(provider.id)} />
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm py-1.5 border-b border-border">
                <span className="text-muted-foreground">{lang === "ar" ? "مفتاح API" : "API Key"}</span>
                <code className="text-xs font-mono text-foreground bg-muted px-2 py-0.5 rounded">{provider.apiKeyMasked}</code>
              </div>
              <div className="flex items-center justify-between text-sm py-1.5 border-b border-border">
                <span className="text-muted-foreground">{lang === "ar" ? "نقطة النهاية" : "Endpoint"}</span>
                <span className="text-xs text-foreground truncate max-w-[200px]">{provider.endpoint}</span>
              </div>
              <div className="flex items-center justify-between text-sm py-1.5">
                <span className="text-muted-foreground">{lang === "ar" ? "الاستخدام هذا الشهر" : "Usage this month"}</span>
                <span className="text-xs font-medium text-foreground tabular-nums">
                  {provider.usageThisMonth.toLocaleString()} tokens
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1"
                onClick={() => handleTest(provider.id)}
                disabled={testing === provider.id}
              >
                {testing === provider.id ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-muted-foreground/30 border-t-muted-foreground rounded-full animate-spin me-1.5" />
                    {lang === "ar" ? "جارٍ الاختبار..." : "Testing..."}
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5 me-1.5" />
                    {lang === "ar" ? "اختبار" : "Test"}
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => toast.info(lang === "ar" ? "فتح المحرر" : "Opening editor")}
              >
                <Edit className="w-3.5 h-3.5" />
              </Button>
              {!provider.isDefault && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => handleDelete(provider.id)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              )}
            </div>

            <div className="mt-3 flex items-center gap-2 text-xs">
              {provider.isActive ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
                  <span className="text-primary">{lang === "ar" ? "نشط ويعمل" : "Active and running"}</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-muted-foreground">{lang === "ar" ? "معطل" : "Disabled"}</span>
                </>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Add provider dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{lang === "ar" ? "إضافة مزود ذكاء" : "Add AI Provider"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <label className="text-sm font-medium">{lang === "ar" ? "الاسم" : "Name"}</label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. OpenAI Production"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">{lang === "ar" ? "المزود" : "Provider"}</label>
              <select
                value={form.provider}
                onChange={(e) => setForm({ ...form, provider: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-xl border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring/50"
              >
                {AI_PROVIDERS.map((p) => (
                  <option key={p.id} value={p.id}>{p.label}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">{lang === "ar" ? "النموذج" : "Model"}</label>
              <Input
                value={form.model}
                onChange={(e) => setForm({ ...form, model: e.target.value })}
                placeholder="e.g. gpt-4o, glm-4.6"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">{lang === "ar" ? "مفتاح API" : "API Key"}</label>
              <Input
                type="password"
                value={form.apiKey}
                onChange={(e) => setForm({ ...form, apiKey: e.target.value })}
                placeholder="sk-..."
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">{lang === "ar" ? "نقطة النهاية" : "Endpoint"}</label>
              <Input
                value={form.endpoint}
                onChange={(e) => setForm({ ...form, endpoint: e.target.value })}
                placeholder="https://api.openai.com/v1"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              {lang === "ar" ? "إلغاء" : "Cancel"}
            </Button>
            <Button onClick={handleSave}>
              {lang === "ar" ? "حفظ" : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
