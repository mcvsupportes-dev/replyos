"use client";

import * as React from "react";
import { PageHeader } from "./page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useLanguage } from "@/components/language-provider";
import { Plus, Edit, Trash2, Star, Check } from "lucide-react";
import { toast } from "sonner";
import type { PlanData } from "@/lib/admin-data";

interface Props {
  plans: PlanData[];
}

export function PlansClient({ plans: initialPlans }: Props) {
  const { lang } = useLanguage();
  const [plans, setPlans] = React.useState(initialPlans);

  const handleDelete = (id: string) => {
    setPlans((prev) => prev.filter((p) => p.id !== id));
    toast.success(lang === "ar" ? "تم حذف الباقة" : "Plan deleted");
  };

  const togglePopular = (id: string) => {
    setPlans((prev) =>
      prev.map((p) => ({ ...p, popular: p.id === id ? !p.popular : false }))
    );
  };

  return (
    <div>
      <PageHeader
        title={lang === "ar" ? "الباقات" : "Plans"}
        description={lang === "ar" ? "إدارة اشتراكات وباقات النظام" : "Manage subscription plans"}
        action={
          <Button>
            <Plus className="w-4 h-4 me-2" />
            {lang === "ar" ? "باقة جديدة" : "Add Plan"}
          </Button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`relative p-6 premium-shadow hover:premium-shadow-lg transition-all duration-300 animate-fade-in ${
              plan.popular ? "ring-2 ring-primary" : ""
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-3 start-1/2 -translate-x-1/2 rtl:translate-x-1/2">
                <Badge className="gap-1">
                  <Star className="w-3 h-3 fill-current" />
                  {lang === "ar" ? "الأكثر شيوعاً" : "Popular"}
                </Badge>
              </div>
            )}

            <div className="mb-4">
              <h3 className="text-lg font-bold text-foreground">
                {lang === "ar" ? plan.nameAr : plan.name}
              </h3>
              <div className="flex items-baseline gap-1 mt-2">
                <span className="text-3xl font-bold text-foreground">${plan.price}</span>
                <span className="text-sm text-muted-foreground">/{plan.interval}</span>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{lang === "ar" ? "حد الردود" : "Replies limit"}</span>
                <span className="font-medium text-foreground">{plan.repliesLimit.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{lang === "ar" ? "حد التخزين" : "Storage limit"}</span>
                <span className="font-medium text-foreground">{(plan.storageLimitMb / 1024).toFixed(0)} GB</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{lang === "ar" ? "المشتركون" : "Subscribers"}</span>
                <span className="font-medium text-foreground">{plan.subscriberCount}</span>
              </div>
            </div>

            <div className="space-y-2 mb-4 pt-4 border-t border-border">
              {(lang === "ar" ? plan.featuresAr : plan.features).map((f, i) => (
                <div key={i} className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <span className="text-foreground">{f}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between mb-4 pt-4 border-t border-border">
              <span className="text-sm text-muted-foreground">{lang === "ar" ? "باقة مميزة" : "Mark as popular"}</span>
              <Switch checked={plan.popular} onCheckedChange={() => togglePopular(plan.id)} />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => toast.info(lang === "ar" ? "فتح محرر الباقة" : "Opening plan editor")}>
                <Edit className="w-3.5 h-3.5 me-1.5" />
                {lang === "ar" ? "تعديل" : "Edit"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-destructive hover:text-destructive"
                onClick={() => handleDelete(plan.id)}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
