import { NextResponse } from "next/server";
import { chat } from "@/lib/ai-provider";

export async function POST() {
  try {
    const result = await chat(
      [{ role: "user", content: "Say 'hello' in one word." }],
      { tone: "friendly", length: "short", maxTokens: 10 }
    );
    return NextResponse.json({
      success: true,
      content: result.content,
      provider: result.provider,
      model: result.model,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
