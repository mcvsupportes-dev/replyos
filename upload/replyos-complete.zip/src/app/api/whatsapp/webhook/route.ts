/**
 * WhatsApp Business Cloud API Webhook endpoint
 * Receives incoming messages and status updates from WhatsApp.
 *
 * Setup in Meta Business:
 *   Webhook URL: https://replyos-1.vercel.app/api/whatsapp/webhook
 *   Verify Token: set via WHATSAPP_VERIFY_TOKEN env var
 */
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");

  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN || "replyos_verify_token";

  if (mode === "subscribe" && token === verifyToken) {
    return new NextResponse(challenge, { status: 200 });
  }

  return NextResponse.json({ error: "Forbidden" }, { status: 403 });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Log incoming webhook for debugging
    console.log("[WhatsApp Webhook]", JSON.stringify(body, null, 2));

    // Process incoming messages
    if (body.object) {
      const entry = body.entry?.[0];
      const change = entry?.changes?.[0];
      const message = change?.value?.messages?.[0];

      if (message) {
        const from = message.from; // phone number
        const text = message.text?.body || "";
        const timestamp = Date.now();

        // Store in Firebase RTDB (best-effort)
        try {
          const { adminDb } = await import("@/lib/firebase-admin");
          const db = adminDb();
          await db.ref(`whatsapp/messages/${from}`).push({
            from,
            text,
            timestamp,
            type: message.type,
            messageId: message.id,
            processed: false,
          });
        } catch {
          // Firebase not configured
        }

        // TODO: Trigger AI auto-reply based on user's rules and settings
      }
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[WhatsApp Webhook Error]", err);
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 });
  }
}
