/**
 * Send a message via WhatsApp Business Cloud API
 * Requires: phoneNumberId, accessToken (stored per-user in Firebase RTDB)
 */
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { to, message, phoneNumberId, accessToken } = await req.json();

    if (!to || !message) {
      return NextResponse.json({ error: "Recipient and message are required" }, { status: 400 });
    }

    if (!phoneNumberId || !accessToken) {
      return NextResponse.json({ error: "WhatsApp credentials not configured" }, { status: 400 });
    }

    const res = await fetch(
      `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to,
          type: "text",
          text: { body: message },
        }),
      }
    );

    const data = await res.json();

    if (!res.ok) {
      return NextResponse.json({ error: data.error?.message || "WhatsApp API error" }, { status: res.status });
    }

    return NextResponse.json({ success: true, messageId: data.messages?.[0]?.id });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
