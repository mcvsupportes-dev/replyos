import { NextRequest, NextResponse } from "next/server";
import { adminStorage, adminDb } from "@/lib/firebase-admin";
import { getAdminSession } from "@/lib/admin-auth";

export async function POST(req: NextRequest) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const category = (formData.get("category") as string) || "general";
    const userId = (formData.get("userId") as string) || "admin";

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    // Validate size (max 10MB)
    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      return NextResponse.json({ error: "File too large (max 10MB)" }, { status: 413 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const ext = file.name.split(".").pop() || "bin";
    const fileName = `${userId}/${category}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

    let url: string;
    let publicUrl: string;

    try {
      // Try Firebase Storage
      const bucket = adminStorage().bucket();
      const fileRef = bucket.file(fileName);
      await fileRef.save(buffer, {
        metadata: {
          contentType: file.type || "application/octet-stream",
        },
      });
      // Make public or get signed URL
      await fileRef.makePublic();
      url = `https://storage.googleapis.com/${bucket.name}/${fileName}`;
      publicUrl = url;
    } catch {
      // Fallback: save to local filesystem (dev only)
      const fs = await import("fs/promises");
      const path = await import("path");
      const localPath = path.join(process.cwd(), "public", "uploads", fileName);
      await fs.mkdir(path.dirname(localPath), { recursive: true });
      await fs.writeFile(localPath, buffer);
      url = `/uploads/${fileName}`;
      publicUrl = url;
    }

    // Save metadata to Realtime Database
    const fileMeta = {
      name: file.name,
      type: file.type || "application/octet-stream",
      size: file.size,
      category,
      uploadedBy: userId,
      uploadedAt: Date.now(),
      url: publicUrl,
      path: fileName,
    };

    let fileId = `file_${Date.now()}`;
    try {
      const db = adminDb();
      const ref = db.ref(`uploads/${userId}`).push();
      fileId = ref.key || fileId;
      await ref.set(fileMeta);
    } catch {
      // Firebase not available — metadata not saved
    }

    return NextResponse.json({
      success: true,
      fileId,
      url: publicUrl,
      name: file.name,
      size: file.size,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
